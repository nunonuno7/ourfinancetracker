# core/cache.py
TX_LAST = {}